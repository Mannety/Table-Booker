from django.apps import AppConfig


class TableBookerConfig(AppConfig):
    name = 'table_booker'
